const New = () => {
    return (
        <div>我是New</div>
    )
}

export default New